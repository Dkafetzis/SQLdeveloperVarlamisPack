#!/bin/bash
cd /opt/sqldeveloper/sqldeveloper/bin && bash sqldeveloper $*
